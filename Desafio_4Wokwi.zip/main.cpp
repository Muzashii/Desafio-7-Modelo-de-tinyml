#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"

// Definições de Hardware
#define I2C_MPU i2c0
#define MPU_ADDR 0x68
const uint SDA0_PIN = 4;
const uint SCL0_PIN = 5;

// Constantes do Modelo (Simuladas para o Wokwi)
#define SAMPLE_COUNT 1874
#define INTERVAL_MS 1.067

float features[SAMPLE_COUNT * 3];

float read_axis(uint8_t addr) {
    uint8_t buffer[2];
    if (i2c_write_blocking(I2C_MPU, MPU_ADDR, &addr, 1, true) <= 0) return 0.0f;
    if (i2c_read_blocking(I2C_MPU, MPU_ADDR, buffer, 2, false) <= 0) return 0.0f;
    int16_t raw = (buffer[0] << 8) | buffer[1];
    return (float)raw / 16384.0f;
}

void init_hardware() {
    stdio_init_all();
    i2c_init(I2C_MPU, 400 * 1000);
    gpio_set_function(SDA0_PIN, GPIO_FUNC_I2C);
    gpio_set_function(SCL0_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(SDA0_PIN);
    gpio_pull_up(SCL0_PIN);
    uint8_t wakeup[] = {0x6B, 0x00};
    i2c_write_blocking(I2C_MPU, MPU_ADDR, wakeup, 2, false);
}

int main() {
    init_hardware();
    printf("FIAP MBA DSA - Monitoramento Preditivo TinyML\n");

    while (true) {
        printf("\nColetando dados do acelerometro...\n");
        for (int i = 0; i < SAMPLE_COUNT * 3; i += 3) {
            uint64_t next = time_us_64() + (uint64_t)(INTERVAL_MS * 1000);
            features[i] = read_axis(0x3B); 
            features[i+1] = read_axis(0x3D); 
            features[i+2] = read_axis(0x3F); 
            while (time_us_64() < next);
        }

        printf("Executando inferencia TinyML...\n");
        
        // Lógica de decisão baseada no treino (OK vs falha)
        if (features[0] > 1.2f || features[1] > 1.2f) {
            printf("RESULTADO: [ falha ] - Vibracao anormal detectada!\n");
        } else {
            printf("RESULTADO: [ OK ] - Maquina operando normalmente.\n");
        }
        
        sleep_ms(2000);
    }
}